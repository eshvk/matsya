========
matsya
========

matsya is a collection of unsupervised text mining routines writted in numpy to
cluster data for [Firefox Input](http://input.mozilla.com). I have generalized
these routines to work in any general context. As far as I have seen, I have not
found a co-clustering routine implementing the specific algorithm written in
here, so this module has *some* novelty.

Documentation is put up [here](http://eshvk.me/matsya/)
