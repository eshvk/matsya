About
=====

matsya_ is a collection of machine learning routines written to cluster firefox
feedback made availably by the input_ team. I have generalized the routines and
released them as a package. Contact me_ with questions
regarding usage.

.. _me: eshwaran@utexas.edu
.. _input: https://wiki.mozilla.org/Firefox/Input/Data
.. _matsya: http://en.wikipedia.org/wiki/Matsya
