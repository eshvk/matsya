########
Matsya
########


Contents:

.. toctree::
   :maxdepth: 2

   about
   kmeans
   spectral_coclustering

* :ref:`search`

